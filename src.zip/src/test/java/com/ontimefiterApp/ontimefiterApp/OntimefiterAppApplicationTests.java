package com.ontimefiterApp.ontimefiterApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OntimefiterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
