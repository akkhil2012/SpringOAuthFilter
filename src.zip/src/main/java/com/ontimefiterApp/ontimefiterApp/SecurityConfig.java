package com.ontimefiterApp.ontimefiterApp;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

	private static final String[] PROTECTED_URLS = {"/api/**", "/api/*" ,"/swagger-ui.html", "/v3/api-docs/**", "/swagger-ui/**", "/webjars/swagger-ui/**"};
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http.cors().and().headers().contentSecurityPolicy("frame-ancestors 'none'").and()
				.referrerPolicy(ReferrerPolicyHeaderWriter.ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN).and()
				.frameOptions().deny().and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and().csrf().disable()
				.authorizeHttpRequests(authorize -> authorize
                        .requestMatchers(PROTECTED_URLS).permitAll()
                        .anyRequest().authenticated());
		return http.build();
	}
	
	@Bean
	public FilterRegistrationBean<CustodianAuthenticationFilter> createAuthenticationFilter() {
		
		FilterRegistrationBean<CustodianAuthenticationFilter> filterRegistrationBean = new FilterRegistrationBean<>();
		CustodianAuthenticationFilter filter = new CustodianAuthenticationFilter();
		
		filterRegistrationBean.setFilter(filter);
		filterRegistrationBean.addUrlPatterns("/api/*");
		filterRegistrationBean.setOrder(-1);
		
		return filterRegistrationBean;
				
	}
	
	/*
	 * @Bean public FilterRegistrationBean<CustodianRequestDataValidationFilter>
	 * createRequestDataValidationFilter() {
	 * FilterRegistrationBean<CustodianRequestDataValidationFilter>
	 * filterRegistrationBean = new FilterRegistrationBean<>();
	 * CustodianRequestDataValidationFilter filter = new
	 * CustodianRequestDataValidationFilter();
	 * filterRegistrationBean.setFilter(filter);
	 * filterRegistrationBean.addUrlPatterns("/*");
	 * filterRegistrationBean.setOrder(1); return filterRegistrationBean; }
	 */
}
