package com.ontimefiterApp.ontimefiterApp;

import java.io.IOException;
import java.util.logging.Logger;

import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CustodianAuthenticationFilter extends OncePerRequestFilter{
	

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String uri = request.getRequestURI();
		// By pass token check for Custodian health check url
		if (uri.endsWith("api-docs")) {
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			filterChain.doFilter(request, response);
			
			
		}else {
			// get the auth token
			String sessionToken = request.getHeader("rm-sec-tok");
			boolean isValid = false;
			try {
				ResponseEntity<String> tokenResponse = restTemplateWrapper.exchange(authValidateToken, HttpMethod.GET,
						null, sessionToken, MediaType.APPLICATION_JSON, String.class);
				Gson gson = new Gson();
			
			filterChain.doFilter(request, response);
			System.out.println("Aftre filter part....");
		}
		
	}

}
